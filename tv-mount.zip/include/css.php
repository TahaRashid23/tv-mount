<link href="css/vendor.css" rel="stylesheet">
<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
<link href="css/style.css" rel="stylesheet">