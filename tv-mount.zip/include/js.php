<script src="js/plugins.js"></script>
<script src="js/app.js"></script>